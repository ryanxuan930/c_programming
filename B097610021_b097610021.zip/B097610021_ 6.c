#include <stdio.h>

int main(){
	int a=0, b=0, c=0, ind=0;
	scanf("%d %d %d",&a,&b,&c);
	if(a>0){
		a=1;
	}
	if(b>0){
		b=1;
	}
	if(c>0){
		c=1;
	}
	if((a&b)==c){
		puts("AND");
		ind=1;
	}
	if((a|b)==c){
		puts("OR");
		ind=1;
	}
	if((a^b)==c){
		puts("XOR");
		ind=1;
	}
	if(ind==0){
		puts("IMPOSSIBLE");
	}
	return 0;
}
