#include <stdio.h>

int main(){
	puts("Name: �i�fޱ");
	puts("Student ID: 097610021");
	printf("My secret code is %d",97610*1%1000);
	return 0;
}
