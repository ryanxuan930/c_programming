#include <stdio.h>

int main(){
	double x=0, y=0, z=0;
	printf("x = ");
	scanf("%lf", &x);
	printf("y = ");
	scanf("%lf", &y);
	printf("z = ");
	scanf("%lf", &z);
	printf("(%.4lf+%.4lf) / %.4lf = %.4lf",x, y, z, (x+y*x)/z);
	return 0;
}
