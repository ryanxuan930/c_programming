#include <stdio.h>

int main(){
	int mon=0, day=0;
	while(scanf("%d %d",&mon,&day)){
		if(mon==0 && day==0){
			break;
		}
		switch(mon){
			case 1:
				if(day>=21){
					puts("Aquarius");
				}else{
					puts("Capricorn");
				}
				break;
			case 2:
				if(day>=20){
					puts("Pisces");
				}else{
					puts("Aquarius");
				}
				break;
			case 3:
				if(day>=21){
					puts("Aries");
				}else{
					puts("Pisces");
				}
				break;
			case 4:
				if(day>=21){
					puts("Taurus");
				}else{
					puts("Aries");
				}
				break;
			case 5:
				if(day>=22){
					puts("Gemini");
				}else{
					puts("Taurus");
				}
				break;
			case 6:
				if(day>=22){
					puts("Cancer");
				}else{
					puts("Gemini");
				}
				break;
			case 7:
				if(day>=23){
					puts("Leo");
				}else{
					puts("Cancer");
				}
				break;
			case 8:
				if(day>=22){
					puts("Virgo");
				}else{
					puts("Leo");
				}
				break;
			case 9:
				if(day>=24){
					puts("Libra");
				}else{
					puts("Virgo");
				}
				break;
			case 10:
				if(day>=24){
					puts("Scorpio");
				}else{
					puts("Libra");
				}
				break;
			case 11:
				if(day>=23){
					puts("Sagittarius");
				}else{
					puts("Scorpio");
				}
				break;
			case 12:
				
				if(day>=23){
					puts("Capricorn");
				}else{
					puts("Sagittarius");
				}
				break;		
		}
	}
	return 0;
}
