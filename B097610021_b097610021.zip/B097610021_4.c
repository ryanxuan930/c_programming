#include <stdio.h>

int mult(int num){
	int i=1, data=1;
	for(i=1; i<=num; i++){
		data *= i;
	}
	return data;
}

int main(){
	int rows = 0, i=0, j=0;
	printf("Please input number of rows: ");
	scanf("%d",&rows);
	for(i=0; i<=rows; i++){
		for(j=0; j<=i; j++){
			printf("%d\t",mult(i)/(mult(j)*mult((i-j))));
		}
		puts("\n");
	}
	return 0;
}
