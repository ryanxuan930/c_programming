#include <stdio.h>

int main(){
	int i=0, j=0, k=0, amp=0, fre=0;
	printf("Please input amplitude: ");
	scanf("%d",&amp);
	printf("Please input frequency: ");
	scanf("%d",&fre);
	for(i=0; i<fre; i++){
		for(j=1; j<=(amp*2-1); j++){
			if(j<=amp){
				for(k=1; k<=j; k++){
					printf("%d",j);
				}
			}else{
				for(k=1; k<=(amp*2-j); k++){
					printf("%d",(amp*2-j));
				}
			}
			puts("\n");
		}
		puts("\n");
	}
	return 0;
}
